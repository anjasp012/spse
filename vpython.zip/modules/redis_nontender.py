import asyncio
import aiohttp
import re
import random
import aioredis
import json

instances = [
    "pertanian","jakarta","babelprov","katingankab","malakakab","usu",
    "ui","undip","lkpp","kemenkeu","sumutprov","sumselprov",
    "sumbarprov","sulutprov","sultraprov","sultengprov",
    "sulselprov","sulbarprov","riau",
]

async def scrape_instance(session, redis, slug, tahun, retries=3):
    base = f"https://spse.inaproc.id/{slug}/nontender"

    for attempt in range(1, retries + 1):
        try:
            async with session.get(base) as resp:
                if resp.status != 200:
                    raise Exception(f"GET halaman gagal, status: {resp.status}")

                text = await resp.text()
                cookies = resp.cookies
                cookie_string = "; ".join(f"{k}={v.value}" for k,v in cookies.items())

                match = re.search(r"d\.authenticityToken\s*=\s*'([a-zA-Z0-9]+)'", text)
                token = match.group(1) if match else None
                if not token:
                    raise Exception("Token tidak ditemukan")

            # POST data
            data_url = f"https://spse.inaproc.id/{slug}/dt/pl?tahun={tahun}"
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
                "Content-Type": "application/x-www-form-urlencoded",
                "X-Requested-With": "XMLHttpRequest",
                "Origin": "https://spse.inaproc.id",
                "Referer": "https://spse.inaproc.id/",
                "Cookie": cookie_string
            }
            post_data = {
                "draw": 1,
                "start": 0,
                "length": 1000000,
                "authenticityToken": token
            }

            async with session.post(data_url, headers=headers, data=post_data) as resp:
                if resp.status != 200:
                    raise Exception(f"POST data gagal, status: {resp.status}")

                json_data = await resp.json()
                redis_key = f"spse:{tahun}:nontender"

                # Hapus key lama hanya sekali di awal, bukan di sini
                for row in json_data.get("data", []):
                    row_dict = {str(i): v for i,v in enumerate(row)}
                    row_dict["instansi"] = slug
                    await redis.rpush(redis_key, json.dumps(row_dict))

                return True

        except Exception as e:
            if attempt < retries:
                await asyncio.sleep(random.uniform(0.5, 1.5))
            else:
                print(f"Gagal scrape {slug}: {e}")
                return False

async def fetch_and_store(tahun):
    redis = await aioredis.from_url("redis://localhost")
    redis_key = f"spse:{tahun}:nontender"

    # Hapus key lama di awal
    if await redis.exists(redis_key):
        await redis.delete(redis_key)

    async with aiohttp.ClientSession() as session:
        remaining = instances.copy()
        while remaining:
            tasks = [scrape_instance(session, redis, slug, tahun) for slug in remaining]
            results = await asyncio.gather(*tasks)

            # Filter instance yang gagal
            failed = [remaining[i] for i, r in enumerate(results) if not r]

            if failed:
                print("Ulangi scraping untuk:", failed)
                await asyncio.sleep(2)  # delay sebelum retry
            remaining = failed  # hanya retry instance yang gagal

    await redis.close()
    return True  # return hanya jika semua berhasil

def fetch(tahun):
    return asyncio.run(fetch_and_store(tahun))
