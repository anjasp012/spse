from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from models import db, User
from utils import login_required, role_required
from modules.redis_tender import fetch as redis_tender
from modules.redis_nontender import fetch as redis_nontender
from modules.fetch_tender import fetch as fetch_tender
from modules.fetch_nontender import fetch as fetch_nontender

def create_routes(app):

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                session['user_id'] = user.id
                session['role'] = user.role
                flash("Login berhasil", "success")
                if user.role == 'admin':
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('user_dashboard'))
            else:
                flash("Login gagal", "danger")
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        session.clear()
        flash("Logout berhasil", "info")
        return redirect(url_for('login'))

    @app.route("/admin")
    @login_required
    @role_required('admin')
    def admin_dashboard():
        return render_template("admin_dashboard.html")

    @app.route("/user")
    @login_required
    @role_required('user')
    def user_dashboard():
        return render_template("user_dashboard.html")

    @app.route("/")
    def tender():
        return render_template("tender.html")

    @app.route('/fetch-tender')
    def fetchtender():
        tahun = int(request.args.get('tahun', 2025))
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 100))
        instansi = request.args.get('instansi')
        kategoriId = request.args.get('kategoriId')
        tender = fetch_tender(tahun=tahun, instansi=instansi, kategoriId=kategoriId, page=page, per_page=per_page)
        return jsonify(tender)

    @app.route('/redis-tender', methods=['POST'])
    def redistender():
        data = request.get_json() or {}
        tahun = int(data.get('tahun', 2025))
        tender = redis_tender(tahun=tahun)
        return jsonify(tender)

    @app.route("/non-tender")
    def non_tender():
        return render_template("non-tender.html")

    @app.route('/fetch-non-tender')
    def fetchnon_tender():
        tahun = int(request.args.get('tahun', 2025))
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 100))
        instansi = request.args.get('instansi')
        kategoriId = request.args.get('kategoriId')
        tender = fetch_nontender(tahun=tahun, instansi=instansi, kategoriId=kategoriId, page=page, per_page=per_page)
        return jsonify(tender)

    @app.route('/redis-non-tender', methods=['POST'])
    def redisnontender():
        data = request.get_json() or {}
        tahun = int(data.get('tahun', 2025))
        nontender = redis_nontender(tahun=tahun)
        return jsonify(nontender)
